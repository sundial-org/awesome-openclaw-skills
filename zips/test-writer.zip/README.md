# Test Writer

Generate unit tests from source files with one command. Supports Jest, Vitest, and Mocha.

## Quick Start

```bash
npx ai-test-gen src/utils.ts
```

## Links

- [MoltHub Page](https://clawdhub.com/lxgicstudios/test-writer)
- [GitHub](https://github.com/LXGIC-Studios)
- [Website](https://lxgic.dev)

MIT License.