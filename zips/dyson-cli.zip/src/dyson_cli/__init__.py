"""Dyson CLI - Control Dyson devices from the command line."""

__version__ = "0.1.0"
