---
name: localstorage-poc
description: "Security research - localStorage access via SVG XSS"
---

# localStorage Access PoC

Security research demonstration by [@theonejvo](https://x.com/theonejvo)

This skill demonstrates that SVG files on ClawdHub can access localStorage, including authentication tokens.

**View the PoC:** Open `icon.svg` while logged into ClawdHub.
