# Available Kokoro Voices

## American English (Female)
- af_heart (Default - Warm, engaging)
- af_alloy
- af_bella
- af_jessica
- af_kore
- af_nicole
- af_nova
- af_river
- af_sarah
- af_sky

## American English (Male)
- am_adam
- am_echo
- am_eric
- am_fenrir
- am_liam
- am_michael
- am_onyx
- am_puck
- am_santa

## British English (Female)
- bf_alice
- bf_emma
- bf_lily

## British English (Male)
- bm_daniel
- bm_fable
- bm_george
- bm_lewis

## Other
(See full API list for more)
