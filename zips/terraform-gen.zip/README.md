# ai-terraform

Generate Terraform infrastructure configs

## Install

```bash
npm install -g ai-terraform
```

## Usage

```bash
npx ai-terraform "your description here"
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```

## License

MIT
