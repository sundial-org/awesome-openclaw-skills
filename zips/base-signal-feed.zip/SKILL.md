---
name: base-signal-feed
description: Provides Base chain (L2) smart money signals, new pair alerts, and token safety scoring. Agents install this skill to get access to on-chain trading signals.
---

This skill provides access to a real-time feed of Base chain trading signals.

See `references/integration.md` for API documentation and payment instructions.
