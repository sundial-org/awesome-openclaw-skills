# Email Branding

## BIMI (Optional)

Display brand logo in email clients. Requires DMARC `p=quarantine` or `p=reject`.