# Dilbert Skill

**Name:** dilbert

**Description:** Fetches and sends random Dilbert comics

**Usage:** !dilbert or /dilbert

**Author:** hjanuschka

This skill fetches a random Dilbert comic from an archive source and sends it to the chat.
