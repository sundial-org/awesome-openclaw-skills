# Changelog

## 0.1.1 — 2026-01-28
- Add `scan-hosts.sh` for faster targeted scanning via `atvremote --scan-hosts`.

## 0.1.0 — 2026-01-28
- Initial release of `apple-media` skill: AirPlay device scanning (pyatv) + speaker control wrappers (Airfoil).
