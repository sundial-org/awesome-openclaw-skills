# ai-cloudflare

Generate Cloudflare Workers configuration and code

## Install

```bash
npm install -g ai-cloudflare
```

## Usage

```bash
npx ai-cloudflare "your description here"
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```

## License

MIT
