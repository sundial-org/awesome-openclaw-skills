# ai-monitoring

Generate monitoring and alerting configuration

## Install

```bash
npm install -g ai-monitoring
```

## Usage

```bash
npx ai-monitoring "your description here"
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```

## License

MIT
