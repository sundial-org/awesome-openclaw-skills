# Reminder Plan

Reporting period:
Owner:

| Trigger | Audience | Lead time | Channel | Message template location | Status |
|---------|----------|----------:|---------|---------------------------|--------|
| MPQC expiry | Drivers + manager | 60/30/14 days | email/SMS | [path] | |
| CPC due | Drivers + manager | 90/60/30 days | email | [path] | |
| Toolbox talk | Depot | weekly | brief | [path] | |
