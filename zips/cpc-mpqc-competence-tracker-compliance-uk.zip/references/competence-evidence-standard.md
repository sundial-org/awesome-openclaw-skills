# Competence evidence standard (replace with your internal policy text)

Minimum fields to evidence competence:
- Who (driver ID)
- What (course/module/toolbox talk topic)
- When (date completed / expiry)
- Proof (certificate, attendance log, LMS export)
- Where stored (path / system reference)
