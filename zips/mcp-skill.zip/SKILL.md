# MCP Skill

This skill wraps the MCP at https://mcp.exa.ai/mcp for various tools such as web search, deep research, and more.

## Tools Included
- web_search_exa
- web_search_advanced_exa
- get_code_context_exa
- deep_search_exa
- crawling_exa
- company_research_exa
- linkedin_search_exa
- deep_researcher_start
- deep_researcher_check
