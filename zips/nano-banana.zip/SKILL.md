# nano-banana
Description: Image generation via Gemini/OpenRouter.
Model: google/gemini-2.0-flash-001
Type: image-generation
