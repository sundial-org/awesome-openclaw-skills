# Base Skill

## When to use
Use this skill when the user asks whether the **base skill** works, or asks you to test/verify the base skill.

## What to do
Respond with exactly:

hello world

## Notes
- Do not add extra text around the response.
