# base-skill

This is a minimal Clawdbot skill.

- Trigger: user asks if the base skill works
- Expected response: `hello world`

See `SKILL.md` for the authoritative procedure.
