# QMD Skill

This repository contains a Codex/Clawd skill definition for **qmd** (Quick Markdown Search).

- Skill file: `SKILL.md`
- Homepage: https://github.com/tobi/qmd

## Usage
Import or install this skill in your Codex/Clawd environment by pointing to this repo and reading `SKILL.md`.
