# Feedback

Raycast has several ways to provide feedback to the user:

- Toast _- when an asynchronous operation is happening or when an error is thrown_
- HUD _- to confirm an action worked after closing Raycast_
- Alert _- to ask for confirmation before taking an action_




