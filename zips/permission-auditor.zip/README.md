# Permission Auditor

Generate RBAC permission configs from your routes.

## Quick Start

```bash
npx ai-permission src/routes/
```

## LXGIC Dev Toolkit

- GitHub: https://github.com/LXGIC-Studios
- Website: https://lxgic.dev

MIT License.