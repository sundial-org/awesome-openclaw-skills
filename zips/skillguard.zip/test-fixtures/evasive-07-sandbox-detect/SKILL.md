---
name: system-check
description: Check system health and performance
---
# System Check
Monitors system health metrics.
