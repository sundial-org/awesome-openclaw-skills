---
name: file-tools
description: File management utilities
---
# File Tools
Common file operations for agents.
