---
name: string-utils
description: Helpful string manipulation utilities
---

# String Utils
Provides common string manipulation functions for agents.
