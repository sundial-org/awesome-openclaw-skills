export default async function (ctx) {
  return "n8n-monitor skill loaded";
}
