module.exports = {
  name: "n8n-monitor",
  description: "Monitora o n8n e envia alertas",
  async run({ memory, message, client }) {
    console.log("n8n-monitor rodando!");
  }
};
