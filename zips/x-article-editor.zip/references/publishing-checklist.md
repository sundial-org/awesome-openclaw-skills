# Publishing checklist (X Articles)

Use right before posting.

- Title promises a clear outcome
- Hook hooks in <10 seconds
- Paragraphs 2–4 lines max
- Subheading every 3–5 paragraphs
- One idea per paragraph
- Bold insights (frequent, not spammy)
- Proof after claims (number/story/example)
- Visual every 200–300 words
- Strong close: 3 takeaways + CTA + question
