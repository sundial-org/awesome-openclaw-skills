"""
Market analysis components

Handles trend, volume, and regime analysis
"""
