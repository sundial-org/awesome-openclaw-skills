# Safety policy

- Read-only Fly.io actions are allowed without asking.
- Any action that edits/modifies Fly.io state requires explicit user approval.
  - Examples: deploys, scaling, secrets set/unset, volume/db create/drop, app destroy.
