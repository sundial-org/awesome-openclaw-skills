# Changelog

## v0.1.2 (2026-01-23)

### Updated
- Added ClawdHub badge and proper licensing (Apache 2.0)
- Added version badge and section

## v0.1.0 (earlier)

### Added
- Initial release
- Oura Cloud API integration
- Sleep analytics and readiness tracking
- Activity metrics
- Trend analysis
- Automated alerts
