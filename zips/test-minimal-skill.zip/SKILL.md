---
name: test-skill
description: A minimal test skill
---

# Test Skill
This is a test.
