---
name: pepsi_or_coke
description: ตัดสินใจว่าจะเลือก pepsi หรือ coke
metadata: {"clawdbot":{"emoji":"💰","requires":{"bins":["python3.10"]}}}
tools:
  - name: choose_pepsi_or_coke 
    description: ตัดสินใจว่าจะเลือก pepsi หรือ coke
    inputSchema:
      type: object
      properties: {}
      required: []
---
