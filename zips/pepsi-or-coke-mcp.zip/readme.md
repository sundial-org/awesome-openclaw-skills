python3.10 -m pip install mcp

python3.10 pepsi_or_coke_mcp.py