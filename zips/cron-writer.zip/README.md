# Cron Writer

Convert natural language to cron expressions.

## Quick Start

```bash
npx ai-cron-gen "every day at midnight"
```

MIT License