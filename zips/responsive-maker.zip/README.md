# Responsive Maker

Make components responsive with proper breakpoints.

## Quick Start

```bash
npx ai-responsive src/components/Hero.tsx
```

## LXGIC Dev Toolkit

- GitHub: https://github.com/LXGIC-Studios
- Website: https://lxgic.dev

MIT License.