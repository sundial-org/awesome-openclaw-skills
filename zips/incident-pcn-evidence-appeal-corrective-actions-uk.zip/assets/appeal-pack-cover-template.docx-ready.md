# PCN Appeal Cover (Word-ready text)

To: [Authority/Issuer]
PCN reference:
Vehicle registration:
Date of notice:
Location:

We are submitting an appeal regarding the above PCN.

## Summary
- [1–3 bullet factual points]

## Evidence enclosed
- Ref 1: [description]
- Ref 2: [description]
- …

## Detailed points (factual, evidence-linked)
1) [Point] — supported by Ref [x]
2) [Point] — supported by Ref [y]

We request that you review the enclosed evidence and confirm the outcome in writing.

Regards,
[Name]
Compliance Manager
[Company]
