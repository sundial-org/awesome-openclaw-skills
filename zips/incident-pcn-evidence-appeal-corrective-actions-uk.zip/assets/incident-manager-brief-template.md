# Manager Brief (clean summary)

Case ref:
Type: Incident / PCN / Both
Deadline (if any):
Driver/vehicle:
Location/date/time:

## Summary (facts only)
- …

## What we know (evidence list)
- [Ref] …

## What we don’t yet know (gaps)
- …

## Immediate actions taken
- …

## Recommended next steps
- …
