## Session rules

- Opencode keeps a history of projects
- The same project must always use the same session
- Reusing sessions preserves context and decisions
- Starting a new session is allowed only if the user explicitly asks
- Open session selector using:
  /sessions

If unsure, ask the user before creating a new session.
