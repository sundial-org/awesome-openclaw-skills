## Core Opencode commands

- Start Opencode:
  opencode

- Session selection:
  /sessions

- Agent (mode) selection:
  /agents

- Model selection:
  /models
