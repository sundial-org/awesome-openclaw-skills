## Handling questions from Opencode

- If Opencode asks a question:
  - Switch to Plan mode immediately
  - Answer carefully
  - Confirm or revise the plan

Never answer questions in Build mode.
