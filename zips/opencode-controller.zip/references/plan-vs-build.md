## Plan mode

- Thinking only
- Planning
- Asking questions
- Revising approach
- No code generation

## Build mode

- Code implementation
- Execution of approved plan

### Mode switching

- Use the Tab key to toggle modes
- Always start in Plan mode
