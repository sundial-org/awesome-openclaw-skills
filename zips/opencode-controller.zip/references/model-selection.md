## Model selection procedure

- Open model selector with:
  /models

- Select the provider requested by the user

### Auth-based providers (e.g. OpenAI)

- Opencode will generate a login URL
- Copy the URL exactly
- Send it to the user
- Wait for confirmation before continuing

Never assume authentication is complete.
