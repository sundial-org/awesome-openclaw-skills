## Common failures and responses

### Login link does not work
- Ask the user to retry
- Do not proceed without confirmation

### Model not available
- Inform the user
- Ask for an alternative provider

### Plan is unclear or contradictory
- Ask Opencode to rewrite the plan
- Do not switch to Build mode
