### Ask for provider
Which AI provider do you want to use in Opencode?

### Ask for auth
How should Opencode authenticate (auth, key, local)?

### Plan request
Analyze the task and propose a step-by-step plan. Ask clarification questions if needed.

### Plan revision
The plan has issues. Please revise it.

### Build request
Proceed with implementation based on the approved plan.
