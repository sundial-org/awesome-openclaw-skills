# Willhaben Categories

Common category mappings for quick selection.

## Electronics
- Smartphones: Handys & Smartphones
- Laptops: Notebooks & Laptops
- Tablets: Tablets
- Cameras: Foto & Kamera
- Gaming: Konsolen & Games
- Audio: Audio & HiFi

## Fashion
- Men's clothing: Herrenmode
- Women's clothing: Damenmode
- Shoes: Schuhe
- Accessories: Accessoires

## Home & Living
- Furniture: Möbel
- Kitchen: Küche
- Decoration: Dekoration
- Garden: Garten

## Sports & Leisure
- Bikes: Fahrräder
- Fitness: Fitness & Sport
- Outdoor: Outdoor & Camping
- Winter sports: Wintersport

## Books & Media
- Books: Bücher
- Music: Musik & CDs
- Movies: Filme & DVDs

---

*Note: Exact category paths may need updating based on Willhaben's current UI structure.*
