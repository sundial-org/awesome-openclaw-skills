# Learnings Log

Captured learnings, corrections, and discoveries. Review before major tasks.

---
