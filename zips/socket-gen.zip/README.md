# ai-socket

Generate WebSocket handlers with Socket.io

## Install

```bash
npm install -g ai-socket
```

## Usage

```bash
npx ai-socket "your description here"
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```

## License

MIT
