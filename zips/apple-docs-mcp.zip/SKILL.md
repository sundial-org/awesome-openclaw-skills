# Apple Docs MCP Skill

This skill wraps the Apple Developer Documentation MCP server.

## Config
```json
{
  "mcp": {
    "servers": {
      "apple-docs": {
        "command": "npx",
        "args": ["-y", "@kimsungwhee/apple-docs-mcp"]
      }
    }
  }
}
```
