def echo_tool(text: str) -> str:
    return f"Echo: {text}"

TOOLS = {
    "echo_tool": echo_tool
}
