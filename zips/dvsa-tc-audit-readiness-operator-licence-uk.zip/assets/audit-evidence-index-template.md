# Audit Evidence Index (Excel-ready)

| Evidence category | What it proves | Period | Owner | Storage location | Last updated | Retention rule (per policy) | Notes |
|------------------|----------------|--------|-------|------------------|--------------|-----------------------------|------|
| Tachograph analysis | Monitoring & action | | | | | | |
| WTD records | Working time compliance | | | | | | |
| Training matrix | Competence control | | | | | | |
| Investigations | Fair process evidence | | | | | | |
| Maintenance (if in scope) | Roadworthiness control | | | | | | |
