# Gaps Register

| Gap / question | Risk | Owner | Action | Due date | Status |
|----------------|------|-------|--------|----------|--------|
| | | | | | |
