# Operator licence sensitivity notes (replace with your internal standards)

Use this section to paste your internal “operator licence sensitive” topics and evidence expectations:
- Governance: who is responsible and how oversight is shown
- Monitoring: how infringements are identified and corrected
- Escalation: how repeat issues move from coaching to formal steps
- Record keeping: what is retained, where, and for how long (per your policy)
