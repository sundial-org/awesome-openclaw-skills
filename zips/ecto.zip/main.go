package main

import "github.com/visionik/ecto/cmd"

func main() {
	cmd.Execute()
}
