# Agentic Compass — Notes

- Local-only; no network calls.
- Heuristics are intentionally lightweight.
- Extend by adding domain-specific keywords.
