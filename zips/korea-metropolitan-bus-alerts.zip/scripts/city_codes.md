# TAGO cityCode notes (placeholder)

TAGO APIs often require a `cityCode` (e.g., 25, 37060, ...).

In MVP we ask the user to provide the city code.

TODO: add a small lookup table or an API-based resolver.
