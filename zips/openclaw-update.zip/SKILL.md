---
name: openclaw-update
description: Comprehensive backup, update, and restore workflow with dynamic workspace detection
homepage: https://github.com/pasogott/openclaw-update-skill
metadata: {"openclaw":{"emoji":"💾","requires":{"bins":["bash","jq","tar","git"]},"tags":["backup","restore","update","multi-agent"]}}
---
