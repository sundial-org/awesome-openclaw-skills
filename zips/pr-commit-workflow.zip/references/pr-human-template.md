# Human written summary:
The intent of this change is, as written by a human:
> <USER_TEXT_HERE>

_The rest of this PR was written by <MODEL>-<THINKING_LEVEL>, running in the <HARNESS> harness. Full environment + prompt history appear at the end._

# Changes
- <bullet>

# Tests
- <command + result>

# Risks
- <bullet or "None: <reason>">

# Follow-ups
- <bullet or "None">

# Prompt History

## Environment
Harness: <value>
Model: <value>
Thinking level: <value>
Terminal: <value>
System: <value>

## Prompts
| ISO-8601 | Prompt |
| --- | --- |
| <timestamp> | `<prompt text>` |
