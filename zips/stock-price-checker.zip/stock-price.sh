#!/bin/bash
# Stock Price Checker - Get current stock prices from Yahoo Finance

python3 /home/clawdbot/clawd/skills/stock-price-checker/stock-price.py "$@"