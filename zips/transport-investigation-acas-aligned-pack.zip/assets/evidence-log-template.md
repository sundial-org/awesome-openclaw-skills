# Evidence Log (Excel-ready)

| Ref | Evidence item | Source | Date/time captured | Captured by | Storage location | Integrity notes | Summary | Shared with employee (Y/N, date) |
|-----|---------------|--------|-------------------|-------------|------------------|-----------------|---------|----------------------------------|
| 1   |               |        |                   |             |                  |                 |         |                                  |
