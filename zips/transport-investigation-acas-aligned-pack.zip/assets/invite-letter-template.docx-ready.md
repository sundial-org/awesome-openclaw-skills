# Investigation Meeting Invite (Word-ready text)

Private & confidential

To: [Name]
From: [Name/Role]
Date: [date]

Subject: Investigation meeting – [brief neutral topic]

We are inviting you to an investigation meeting as part of a fact-finding process regarding [neutral description]. No decision has been made at this stage.

Meeting details:
- Date/time:
- Location / Teams link:
- Chair:
- Note-taker:
- Expected duration:

Purpose:
- To understand what happened and gather information.

Right to be accompanied:
- You may be accompanied by a work colleague or an accredited representative. Please let us know who will attend with you.

Evidence:
- We will share the evidence we intend to discuss (or list what is currently available) and you can provide your own information.

If you have any questions or need reasonable adjustments, please contact [name].

Regards,
[Name]
[Role]
