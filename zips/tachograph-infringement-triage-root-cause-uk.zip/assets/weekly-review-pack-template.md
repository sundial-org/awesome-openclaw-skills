# Weekly Tacho & WTD Compliance Review Pack

Week/period:
Drivers included:
Sources:

## Summary dashboard
- Total infringements:
- Drivers with repeat issues:
- Any red triggers (per RAG policy):
- Data gaps/risks (missing downloads, incomplete records):

## By driver (action queue)
### Driver:
Facts:
Likely causes (prompts):
What to check next:
Follow-up action:
Review date:
