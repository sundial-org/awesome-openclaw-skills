# CSS to Tailwind Converter

Convert CSS files to Tailwind utility classes.

## Quick Start

```bash
npx ai-css-to-tailwind styles.css
```

## LXGIC Dev Toolkit

- GitHub: https://github.com/LXGIC-Studios
- Website: https://lxgic.dev

MIT License.