# ms-outlook-teams-assistant
Desktop-first Outlook + Teams nagging + email reply drafting for OpenClaw (Windows).
