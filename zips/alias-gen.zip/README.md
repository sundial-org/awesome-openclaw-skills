# ai-alias

Generate useful shell aliases from your command history

## Install

```bash
npm install -g ai-alias
```

## Usage

```bash
npx ai-alias
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```
