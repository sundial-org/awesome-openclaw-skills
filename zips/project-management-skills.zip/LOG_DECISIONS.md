# Decisions (Append-Only Cache)

Record **clear, detailed decisions** (context, alternatives, rationale, evidence) here. Add concise references in `~/.openclaw/workspace/MEMORY.md`.

- **timestamp:**
- **project_id:**
- **decision:**
- **alternatives:**
- **rationale:**
- **consequences:**
- **links:**
