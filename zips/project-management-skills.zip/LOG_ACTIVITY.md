# Log (Append-Only Cache)

Use this section for **clear, detailed entries** (full context, rationale, and evidence). Add concise references to these entries in `~/.openclaw/workspace/MEMORY.md`.

- **timestamp:**
- **project_id:**
- **action:**
- **result:**
- **links:**
