# Primary Follow-Up Template (Day 0 - Within 4 Hours)

**Purpose**: Capitalize on fresh interest while conversation is top-of-mind
**Channel**: SMS
**Timing**: Same day within 4 hours

---

Hi {name}!

Thanks for checking out ShapeScale today! Quick question — what's the #1 thing you want to show your patients with 3D body scanning?

Reply and let me know, or book a free scan for yourself: {checkout_link}

Looking forward to hearing from you!

— Martin
