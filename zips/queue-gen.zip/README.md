# ai-queue

Generate BullMQ job queue setup and workers

## Install

```bash
npm install -g ai-queue
```

## Usage

```bash
npx ai-queue "your description here"
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```

## License

MIT
