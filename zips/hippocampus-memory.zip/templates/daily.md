# {{DATE}}

## Facts Learned
- [User] 
- [Self] 
- [World] 

## Decisions Made
- 

## Emotional Moments
- 

## Reflections
- 

---
*Template from hippocampus skill*
