# ai-redis-schema

Generate Redis key patterns and data structure designs

## Install

```bash
npm install -g ai-redis-schema
```

## Usage

```bash
npx ai-redis-schema "your description here"
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```

## License

MIT
