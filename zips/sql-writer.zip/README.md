# SQL Writer

Convert natural language to SQL queries.

## Quick Start

```bash
npx ai-sql "get all users who signed up this month"
```

MIT License