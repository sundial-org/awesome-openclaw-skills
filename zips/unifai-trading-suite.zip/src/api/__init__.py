"""API module for the trading agent."""

from .server import app

__all__ = ["app"]
