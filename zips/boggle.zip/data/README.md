# Dictionary files

Dictionary files are too large for ClawHub (22MB). They are auto-downloaded on first run.

Or download manually from:
https://github.com/christianhaberl/boggle-openclaw-skill/tree/main/data
