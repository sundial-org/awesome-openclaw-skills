# [TODO: Reference Document Name]

[TODO: This file contains reference documentation that Claude can load when needed.]

[TODO: Delete this file if you don't have reference documentation to provide.]

## Purpose

[TODO: Explain what information this document contains]

## When Claude Should Use This

[TODO: Describe specific scenarios where Claude should load this reference]

## Content

[TODO: Add your reference content here - schemas, guides, specifications, etc.]

---

**Note**: This file is NOT loaded into context by default. Claude will only load it when:
- It determines the information is needed
- You explicitly ask Claude to reference it
- The SKILL.md instructions direct Claude to read it

Keep this file under 10k words for best performance.
