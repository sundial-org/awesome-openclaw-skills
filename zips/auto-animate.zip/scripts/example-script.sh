#!/bin/bash

# [TODO: Script Name]
# [TODO: Brief description of what this script does]

# Example script structure - delete if not needed

set -e  # Exit on error

# [TODO: Add your script logic here]

echo "Example script - replace or delete this file"

# Usage:
# ./scripts/example-script.sh [args]
