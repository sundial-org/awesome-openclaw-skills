# assets/meeting-brief-template.md
## Meeting Brief
- Meeting name:
- Date/time (proposed):
- Attendees:
- Purpose:
- Context/background:
- Pre-reads/links:
- Decisions needed:
- Risks/constraints:
- Desired outcomes:
