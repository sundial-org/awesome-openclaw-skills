# assets/action-items-template.md
## Action Items
- Decision(s):
- Action: | Owner: | Due: | Status: | Notes:
- Follow-ups needed:
- Open questions:
