
---

## 5) OPTIONAL FILES (ONLY IF USED)

```md
# assets/context-profile-template.md
## Context Profile (Optional)
- Your name/signature:
- Role/title:
- Company/org:
- Key stakeholders (names + roles):
- Typical response SLA (e.g., same day / 24h):
- Standing meetings (name + cadence):
- Draft tone notes (friendly-professional defaults, phrases to avoid):
- Priorities this quarter:
- “Red lines” (e.g., never promise dates without confirmation):
