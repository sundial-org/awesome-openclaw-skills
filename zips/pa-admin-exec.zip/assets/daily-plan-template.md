# assets/daily-plan-template.md
## Daily Plan (08:00–17:00)
- Top outcomes (1–3):
- Constraints (appointments, deadlines):
- Time blocks:
  - 08:00–09:00
  - 09:00–10:00
  - 10:00–11:00
  - 11:00–12:00
  - 12:00–13:00
  - 13:00–14:00
  - 14:00–15:00
  - 15:00–16:00
  - 16:00–17:00
- Admin sweep (end of day): inbox zero attempt + tomorrow setup
