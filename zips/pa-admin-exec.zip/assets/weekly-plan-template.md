# assets/weekly-plan-template.md
## Weekly Plan (Mon–Fri)
- Weekly outcomes (1–5):
- Key deadlines:
- Meetings to schedule (must end by 16:30):
- Focus blocks:
  - Mon:
  - Tue:
  - Wed:
  - Thu:
  - Fri:
- Risks/blockers:
- Delegations:
