# assets/comms-draft-template.md
## Comms Draft
**Channel:** Email / Slack / Teams / Other  
**To:**  
**Cc:**  
**Subject:**  
**Goal (1 line):**  

**Draft:**
...

**Questions / missing facts:**
- ...
