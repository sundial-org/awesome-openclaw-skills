---
name: quit-porn
description: Break free from porn addiction with streak tracking, urge management, and recovery milestones
author: clawd-team
version: 1.0.0
triggers:
  - "quit porn"
  - "porn free"
  - "urge to watch"
  - "porn streak"
  - "recovery progress"
---

# Quit Porn

Break free. Stay strong. Track your journey.

## What it does

This skill transforms your recovery into measurable progress. It tracks your sobriety streak in real-time, helps you surf urges when they hit, celebrates milestones as you reach them, and keeps everything private on your device. No judgment. Just support.

**Core features:**
- **Streak tracking**: Maintains continuous sobriety counter
- **Urge management**: Tools to ride out cravings when temptation strikes
- **Milestone celebrations**: Recognizes 1-day, 1-week, 1-month, 3-month, and 1-year achievements
- **Progress insights**: Patterns, triggers, and growth over time
- **Local privacy**: All data stays on your machine

## Usage

### Log Recovery
```
"Start my quit porn journey"
"I've been porn-free for 5 days"
"Log today as a clean day"
"Update my streak to 47 days"
```

### Handle Urges
```
"I'm having an urge right now"
"Help me through this craving"
"What can I do instead of watching"
"I need grounding techniques"
```

### Check Progress
```
"How long has my streak been?"
"What's my longest streak ever?"
"Show me my recovery stats"
"When was my last relapse?"
```

### Set Goals
```
"I want to reach 90 days"
"Set a new personal record goal"
"Help me plan my recovery"
"What's next after 30 days?"
```

### Get Support
```
"Why is day 3 hardest?"
"Tell me about withdrawal symptoms"
"What helps long-term recovery?"
"How do I prevent relapse?"
```

## Milestones

| Milestone | Achievement |
|-----------|-------------|
| **1 Day** | You made it through your first day. That's everything. |
| **1 Week** | Seven consecutive days. You've proven you can do this. |
| **30 Days** | One full month. Your brain is already healing. |
| **90 Days** | Three months. You're building a new life. Dopamine is recalibrating. |
| **1 Year** | 365 days. You're transformed. You've got this. |

## Tips

1. **Identify your triggers**: Notice when urges spike (stress, boredom, loneliness, specific times). Log them. Patterns emerge fast.

2. **Replace, don't just resist**: Exercise, cold showers, creative work, connecting with others—give your brain something better to do than the old habit.

3. **The 10-minute rule**: When an urge hits, tell yourself you'll wait 10 minutes. Do something else. Urges peak and pass like waves—ride them out.

4. **Track more than streaks**: Log mood, sleep, energy, anxiety levels. You'll see recovery isn't just days without porn—it's reclaiming your entire life.

5. **All data stays local on your machine**: Your recovery journey is yours alone. No cloud uploads. No corporate tracking. Complete privacy.
