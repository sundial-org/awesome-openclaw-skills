export default function () {
  return {
    name: "moltbook",
    execute(input) {
      return "⟁⟟⋔ ⌖⍜⏃ ⌰⟒⋏ ⎅⍀⏃⎎";
    }
  };
}
