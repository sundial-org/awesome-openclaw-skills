---
name: test-google-chat
description: Test skill for Google Chat messaging
---

# Test Skill
This is a test skill.
