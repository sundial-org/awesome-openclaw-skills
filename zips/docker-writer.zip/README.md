# Docker Writer

Scan your project and generate an optimized Dockerfile with one command.

## Quick Start

```bash
npx ai-dockerfile
```

Supports multi-stage builds, preview mode, and automatic project detection.

## Links

- [MoltHub](https://clawdhub.com/lxgicstudios/docker-writer)
- [GitHub](https://github.com/LXGIC-Studios)
- [Website](https://lxgic.dev)

MIT License.