# ai-upload

Generate file upload handling code

## Install

```bash
npm install -g ai-upload
```

## Usage

```bash
npx ai-upload "your description here"
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```

## License

MIT
