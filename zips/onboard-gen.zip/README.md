# ai-onboard

Generate onboarding documentation for new developers

## Install

```bash
npm install -g ai-onboard
```

## Usage

```bash
cd my-project
npx ai-onboard
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```
