# YBoard cheatsheet

- Scenes sidebar scrolls independently.
- Use **Edit** mode for changes.
- Prefer **Draw Custom Image**.
- Avoid text inside images to prevent overlap.
