# ai-vercel-config

Generate optimized Vercel configuration

## Install

```bash
npm install -g ai-vercel-config
```

## Usage

```bash
npx ai-vercel-config
```

## Setup

```bash
export OPENAI_API_KEY=sk-...
```

## License

MIT
