---
name: morning-briefing
description: Generate personalized morning report with today's reminders, Notion tasks (undone), and vault storage. Use when user asks for morning briefing, daily summary, or &quot;today's plan&quot;. Pulls from Apple Reminders (as calendar proxy) and Notion tasks DB (set NOTION_TASKS_DB or specify DB ID).