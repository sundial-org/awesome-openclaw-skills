# [PATTERN NAME]

## Problem
[What situation triggers this pattern]

## Solution
[The approach]

```
[Code, pseudocode, or step-by-step if relevant]
```

## Trade-offs
**Pros:**
- [Why this works]

**Cons:**
- [Limitations, when NOT to use it]

## Example
[Concrete implementation or real-world use case]

## Related
- [Similar patterns]
- [Patterns this builds on]

---
*Added: YYYY-MM-DD*
