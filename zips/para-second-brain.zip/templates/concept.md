# [CONCEPT NAME]

## What It Is
[One-line definition]

## Why It Matters
[What problem it solves, when you'd need it]

## How It Works
[Explanation with examples]

```
[Code, diagram, or concrete example]
```

## Key Insight
[The "aha" moment — what makes this click. This is the most important part.]

## Related
- [Link to related concepts]
- [Link to related tools]

---
*Added: YYYY-MM-DD*
