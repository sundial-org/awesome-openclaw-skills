# [TOOL NAME]

**Category:** [devtools | productivity | infrastructure | data | etc.]
**Website:** [url]
**Cost:** [free | paid | freemium]

## What It Does
[Brief description]

## Why I Use It
[Personal experience — what problem it solved for you. Not marketing copy.]

## When to Reach For It
[Scenarios where this is the right choice]

## Quick Start
```bash
# Minimal setup/usage to get going
```

## Gotchas
- [Things that tripped you up]
- [Non-obvious limitations]
- [What the docs don't tell you]

## Related
- [Alternatives considered]
- [Tools it pairs well with]

---
*Added: YYYY-MM-DD | Last verified: YYYY-MM-DD*
