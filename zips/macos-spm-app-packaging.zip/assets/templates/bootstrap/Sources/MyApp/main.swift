import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            Text("Hello from MyApp")
                .padding()
        }
    }
}
