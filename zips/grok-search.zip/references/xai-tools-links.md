# xAI tools docs (quick links)

- Search tools (web_search + x_search): https://docs.x.ai/docs/guides/tools/search-tools
- Tools overview: https://docs.x.ai/docs/guides/tools/overview
- API reference (base URL, endpoints): https://docs.x.ai/docs/api-reference
