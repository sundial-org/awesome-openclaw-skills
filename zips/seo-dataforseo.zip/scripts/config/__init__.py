"""Configuration module for DataForSEO toolkit."""
from .settings import settings

__all__ = ["settings"]
