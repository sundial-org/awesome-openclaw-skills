#!/bin/bash
pip install -r "$(dirname "$0")/requirements.txt"
