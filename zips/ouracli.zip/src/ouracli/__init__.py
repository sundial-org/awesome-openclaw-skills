"""OuraCLI - CLI tool for accessing Oura Ring data."""

__version__ = "0.1.0"
